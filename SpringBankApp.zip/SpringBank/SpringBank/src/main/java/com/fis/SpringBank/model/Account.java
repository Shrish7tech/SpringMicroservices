package com.fis.SpringBank.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "account_details")
public class Account {
	@Id
	@Min(value = 100, message = "Account Number cannot be less than 100")
	@Max(value = 1000, message = "Product Id cannot be greater than 1000")
	private long accNo;
	@NotBlank(message = "Customer name cannot be null or whitespace")
	private String custName;
	@Min(value = 1000000000)
	@Max(value = 9999999999L)
	private long mobile;
	@NotBlank(message = "Account Type cannot be null or whitespace")
	private String accType;
	@NotBlank(message = "Branch name cannot be null or whitespace")
	private String branch;
	
	@Min(value=2500,message="Minimum balance is 2500")
	private double balance;

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Account(
			@Min(value = 100, message = "Account Number cannot be less than 100") @Max(value = 1000, message = "Product Id cannot be greater than 1000") long accNo,
			@NotBlank(message = "Customer name cannot be null or whitespace") String custName,
			@Min(1000000000) @Max(9999999999L) long mobile,
			@NotBlank(message = "Account Type cannot be null or whitespace") String accType,
			@NotBlank(message = "Branch name cannot be null or whitespace") String branch,
			@Min(value = 2500, message = "Minimum balance is 2500") double balance) {
		super();
		this.accNo = accNo;
		this.custName = custName;
		this.mobile = mobile;
		this.accType = accType;
		this.branch = branch;
		this.balance = balance;
	}

	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
