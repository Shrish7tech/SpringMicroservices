package com.fis.SpringBank.exception;

public class AccountNotFoundException extends RuntimeException 
{
    public AccountNotFoundException(String message) 
    {
        super(message);
    }
}