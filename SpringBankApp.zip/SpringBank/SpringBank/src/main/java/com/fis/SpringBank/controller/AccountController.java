package com.fis.SpringBank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fis.SpringBank.model.Account;
import com.fis.SpringBank.service.AccountService;

@RestController
@RequestMapping("/accounts")
public class AccountController {

	@Autowired
	private AccountService service;
	
	//http://localhost:8080/accounts/displayAccount/102
	@GetMapping("/displayBalance/{accNo}")
	public double displayAccount(@PathVariable("accNo") long accNo)
	{
		return service.displayBalance(accNo);
	}
	
	@PostMapping("/addAccount")
    public String addAccount(@RequestBody @Validated Account account) {
    	
//    	http://localhost:8080/accounts/addAccount    	
        return service.addAccount(account);
    }

    @PutMapping("/updateAccount")
    public String updateAccount(@RequestBody @Validated Account account) {
    	
//    	http://localhost:8080/accounts/updateAccount
        return service.updateAccount(account);
    }
    
    
    
    @DeleteMapping("/deleteAccount/{accNo}")
    public String deleteAccount(@PathVariable("accNo") long accNo) 
    {
    	
//    	http://localhost:8080/accounts/deleteAccount/1
        return service.deleteAccount(accNo);
    }

    @GetMapping("/getAccount/{accountId}")
    public Account getAccount(@PathVariable("accountId") long accNo)
    {
    	
//    	http://localhost:8080/accounts/getAccount/1
        Account account = service.getAccount(accNo);
            return account;
    }
    
    @GetMapping("/getAllAccounts")
    public List<Account> getAllAccounts() {
    	
//    	http://localhost:8080/accounts/getAllAccounts
        List<Account> accounts = service.getAllAccounts();
        return accounts;
    }

    @PostMapping("/{accNo}/deposit/{amount}")
    public String deposit(@PathVariable("accNo") long accNo, @PathVariable("amount") double amount) {
    	
//    	http://localhost:8080/accounts/{accNo}/deposit/{amount}
    	String response = service.deposit(accNo, amount);
    	return response;
    }
    
    @PostMapping("/{accNo}/withdraw/{amount}")
    public String withdraw(@PathVariable("accNo") long accNo, @PathVariable("amount") double amount) {
    	
//    	http://localhost:8080/accounts/{accNo}/withdraw/{amount}
    	String response = service.withdraw(accNo, amount);
    	return response;
    }
    
    @PostMapping("/fundTransfer/{fromAccountNumber}/{toAccountNumber}/{amount}")
    public String fundTransfer(@PathVariable("fromAccountNumber") long fromAccountNumber, @PathVariable("toAccountNumber") long toAccountNumber, @PathVariable("amount") double amount) {
        
//    	http://localhost:8080/accounts/fundTransfer/{fromAccountNumber}/{toAccountNumber}/{amount}
    	String response = service.fundTransfer(fromAccountNumber, toAccountNumber, amount);
        return response;
    }

}
