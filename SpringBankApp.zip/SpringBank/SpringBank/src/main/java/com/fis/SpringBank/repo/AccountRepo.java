package com.fis.SpringBank.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fis.SpringBank.model.Account;

@Repository
@Transactional
public interface AccountRepo extends JpaRepository<Account,Long>{

	// Display the balance using account number
		@Query("select a.balance from Account a where a.accNo = ?1") 
		public double displayBalance(long accNo);
		
//		deposit	into account
		@Modifying
		@Query("UPDATE Account a SET a.balance = a.balance + :amount WHERE a.id = :accountNo")
		void deposit(@Param("accountNo") long accountId, @Param("amount") double amount);
		
//		withdraw from account
		@Modifying
		@Query("UPDATE Account a SET a.balance = a.balance - :amount WHERE a.id = :accountNo")
		void withdraw(@Param("accountNo") long accountId, @Param("amount") double amount);
		
		//Transferring fund from one sender's account to receivers's account
		@Modifying
		@Query("UPDATE Account fromAccount SET fromAccount.balance = fromAccount.balance - :amount WHERE fromAccount.id = :fromAccountNumber")
		void fundTransferFrom(@Param("fromAccountNumber") long fromAccountNumber, @Param("amount") double amount);
		
		@Modifying
		@Query("UPDATE Account toAccount SET toAccount.balance = toAccount.balance + :amount WHERE toAccount.id = :toAccountNumber")
		void fundTransferTo(@Param("toAccountNumber") long toAccountNumber, @Param("amount") double amount);
			

}

