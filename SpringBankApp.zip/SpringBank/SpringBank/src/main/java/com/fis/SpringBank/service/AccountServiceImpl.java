package com.fis.SpringBank.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.SpringBank.exception.AccountNotFoundException;
import com.fis.SpringBank.model.Account;
import com.fis.SpringBank.repo.AccountRepo;

@Service
public class AccountServiceImpl implements AccountService {
	@Autowired
	private AccountRepo repo;
	@Override
	public double displayBalance(long accNo) {
		// TODO Auto-generated method stub
		double bal=repo.displayBalance(accNo);
		return bal;
	}

	@Override
	public String addAccount(Account account) {
		// TODO Auto-generated method stub
		repo.save(account);
		return "Account added Successfully";
	}

	@Override
	public String updateAccount(Account account) {
		// TODO Auto-generated method stub
		repo.save(account);
		return "Account updated Successfully";
	}

	@Override
	public String deleteAccount(long accNo) {
		// TODO Auto-generated method stub
		repo.deleteById(accNo);
		return "Account Deleted Successfully";
	}

	@Override
	public Account getAccount(long accNo) throws AccountNotFoundException{
		// TODO Auto-generated method stub
		Optional<Account> optional = repo.findById(accNo);
		if (optional.isPresent()) {
			return optional.get();
		} else {
			throw new AccountNotFoundException("Account not found for : " + accNo+" Please enter valid account number");
		}
	}

	@Override
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public String deposit(long accNo, double amount) {
		// TODO Auto-generated method stub
		if (amount > 0) {
			repo.deposit(accNo, amount);
		}
		return amount + "is successfully deposited to " + accNo;
	}

	@Override
	public String withdraw(long accNo, double amount) {
		// TODO Auto-generated method stub
		Account wacc = getAccount(accNo);
		if (amount > 0 && wacc.getBalance() >= amount) {
			repo.withdraw(accNo, amount);
		}
		return amount + "is successfully withdrawn from " + accNo;
	}

	@Override
	public String fundTransfer(long fromAccountNumber, long toAccountNumber, double amount) {
		// TODO Auto-generated method stub
		Account from = getAccount(fromAccountNumber);
   
        
        // No we are transferring funds by depositing to one account and withdrawing from another account
        if (amount > 0 && from.getBalance() >= amount) {
        repo.fundTransferFrom(fromAccountNumber, amount);
    	repo.fundTransferTo(toAccountNumber, amount);
        
   
        }
		return "Fund Transfer of "+ amount+ "is done";
	}

}
