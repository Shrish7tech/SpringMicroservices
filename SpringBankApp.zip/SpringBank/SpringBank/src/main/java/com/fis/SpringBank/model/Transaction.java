package com.fis.SpringBank.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Transaction {
	@Id
	private long accNo;
	private long initBal;
	private long finalBal;
	private String transacType;
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public long getInitBal() {
		return initBal;
	}
	public void setInitBal(long initBal) {
		this.initBal = initBal;
	}
	public long getFinalBal() {
		return finalBal;
	}
	public void setFinalBal(long finalBal) {
		this.finalBal = finalBal;
	}
	public String getTransacType() {
		return transacType;
	}
	public void setTransacType(String transacType) {
		this.transacType = transacType;
	}
	public Transaction(long accNo, long initBal, long finalBal, String transacType) {
		super();
		this.accNo = accNo;
		this.initBal = initBal;
		this.finalBal = finalBal;
		this.transacType = transacType;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}