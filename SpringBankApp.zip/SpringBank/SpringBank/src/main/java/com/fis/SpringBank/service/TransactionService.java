package com.fis.SpringBank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.SpringBank.model.Transaction;
import com.fis.SpringBank.repo.TransactionRepo;

@Service
public class TransactionService {

	@Autowired
	TransactionRepo trepo;

	public void addTransactions(Transaction transaction) {
		trepo.save(transaction);
	}

	public Transaction showTransactions(long accNo) {
		return trepo.findById(accNo).orElse(null);
	}
}
