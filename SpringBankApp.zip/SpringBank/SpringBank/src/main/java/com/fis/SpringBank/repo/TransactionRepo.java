package com.fis.SpringBank.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.SpringBank.model.Transaction;

public interface TransactionRepo extends JpaRepository<Transaction,Long> {

}
