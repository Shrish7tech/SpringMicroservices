package com.fis.SpringBank.service;

import java.util.List;

import com.fis.SpringBank.exception.AccountNotFoundException;
import com.fis.SpringBank.model.Account;

public interface AccountService {
	
	public double displayBalance(long accNo);
	
    public String addAccount(Account account);
    
    public String updateAccount(Account account);
    
    public String deleteAccount(long accNo);
    
    public Account getAccount(long accNo)throws AccountNotFoundException;
    
    public List<Account> getAllAccounts();
    
    public String deposit(long accNo, double amount);
    
    public String withdraw(long accNo, double amount);
    
	public String fundTransfer(long fromAccountNumber, long toAccountNumber, double amount);
}
